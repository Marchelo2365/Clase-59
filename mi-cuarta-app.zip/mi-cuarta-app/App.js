import * as React from 'react';
import { View, Button } from 'react-native';
import SoundButton from './components/SoundButton'
import Encabezado from './components/Encabezado'
import {createAppContainer, createSwitchNavigator} from 'react-navigation'
import HomeScreen from './Screens/HomeScreen'
import ButtonScreen from './Screens/ButtonScreen'

export default class App extends React.Component {
constructor(){
  super()
  this.state={
    counter:0,
    buttonColor:"blue"
  };
}

incrementCounter = () => {
  this.setState({counter:this.state.counter+1})

}

changeColor = () => {
  var letters = "0123456789abcdef"
  var color = "#"

  for(var i = 0; i < 6; i++){
    color += letters[Math.floor(Math.random()*16)]

  }

this.setState({buttonColor:color})


}

componentDidMount(){
  setInterval(this.incrementCounter, 1000)

}

componentDidUpdate(){
  console.log("El valor del contador cambió")

}



  render() {
    return (
      <View>  
      {this.state.counter}
      <Button title = "Color Aleatorio" color= {this.state.buttonColor} onPress={this.changeColor}/>
      <AppContainer/>
      </View>
    );
  }
}


var AppNavigator = createSwitchNavigator ({

HomeScreen:HomeScreen,
ButtonScreen:ButtonScreen
})

const AppContainer = createAppContainer (
  AppNavigator
)