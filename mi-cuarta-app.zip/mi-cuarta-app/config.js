import firebase from 'firebase';

// TODO: Replace the following with your app's Firebase project configuration
const firebaseConfig = {
  apiKey: "AIzaSyCFTDDmxkviCUONsAnxUbSQpizhj-F7mU4",
  authDomain: "quizz-b1ea4.firebaseapp.com",
  databaseURL: "https://quizz-b1ea4-default-rtdb.firebaseio.com",
  projectId: "quizz-b1ea4",
  storageBucket: "quizz-b1ea4.appspot.com",
  messagingSenderId: "257696774264",
  appId: "1:257696774264:web:5b7704ab3480f35391158d"
};

const ap = firebase.initializeApp(firebaseConfig);
export default ap.database();