import * as React from 'react';
import { View } from 'react-native';
import SoundButton from '../components/SoundButton'
import Encabezado from '../components/Encabezado'

export default class ButtonScreen extends React.Component{

render(){
  return(
<View>
<Encabezado/>
<SoundButton color = {this.props.navigation.getParam('color')}/>
</View>


  )
}
}