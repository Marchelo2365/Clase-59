import * as React from 'react';
import SoundButton from '../components/SoundButton'
import Encabezado from '../components/Encabezado'
import { Text, View, StyleSheet, TouchableOpacity} from 'react-native';

export default class HomeScreen extends React.Component{

goToButtonScreen = (buttonColor) =>{

this.props.navigation.navigate('ButtonScreen',{color:buttonColor})


}

render(){
  return(
<View>
<TouchableOpacity
        style={[styles.button, {backgroundColor:'red'}]}
        onPress={()=>this.goToButtonScreen('red')}>
        <Text
          style={styles.buttonText}>
          Equipo rojo
        </Text>
      </TouchableOpacity>
<TouchableOpacity
        style={[styles.button, {backgroundColor:'yellow'}]}
        onPress={()=>this.goToButtonScreen('yellow')}>
        <Text
          style={styles.buttonText}>
          Equipo amarillo
        </Text>
      </TouchableOpacity>
<TouchableOpacity
        style={[styles.button, {backgroundColor:'blue'}]}
        onPress={()=>this.goToButtonScreen('blue')}>
        <Text
          style={styles.buttonText}>
          Equipo azul
        </Text>
      </TouchableOpacity>
<TouchableOpacity
        style={[styles.button, {backgroundColor:'green'}]}
        onPress={()=>this.goToButtonScreen('green')}>
        <Text
          style={styles.buttonText}>
          Equipo verde
        </Text>
      </TouchableOpacity>

</View>



  )
}

}

const styles = StyleSheet.create({
  button: {
    marginTop: 20,
    marginLeft: 100,
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    width: 200,
    height: 40,
    borderRadius: 100,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 20,
  }
});