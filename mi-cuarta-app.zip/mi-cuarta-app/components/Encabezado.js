import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';

class Encabezado extends React.Component {

  render() {
    return(
      <View>
      <Text
      style={styles.text}>
      Timbre Quiz
      </Text>   
    </View>
    );
  }
}

const styles = StyleSheet.create({
text: {
  fontSize:40,
  backgroundColor:'#abcdcc',
  marginTop: 30,
  alignItems:'center',
  justifyContent: 'center',
  textAlign:'center',
  fontFamily:'Arial',
  fontWeight: 'bold'

}





  
})

export default Encabezado;


